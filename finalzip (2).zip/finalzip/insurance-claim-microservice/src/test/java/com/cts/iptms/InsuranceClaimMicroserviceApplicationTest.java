package com.cts.iptms;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.mockito.junit.jupiter.MockitoExtension;
import com.cts.iptms.model.InitiateClaim;
import com.cts.iptms.model.InsurerDetail;
import com.cts.iptms.repository.InitiateClaimRepository;
import com.cts.iptms.repository.InsurerDetailRepository;
import com.cts.iptms.service.InsuranceClaimServiceImpl;

@ExtendWith(MockitoExtension.class)
class InsuranceClaimMicroserviceApplicationTest {

@InjectMocks
InsuranceClaimServiceImpl insuranceClaimServiceImpl;
@Autowired
InsurerDetailRepository insurerDetailRepository;
@Autowired
InitiateClaimRepository initiateClaimRepository;

 @Test
void testGetName() {
InsurerDetail Id= new InsurerDetail(1, "Bajaj Insurance", "Gold" ,3000,10);
assertEquals("Bajaj Insurance",Id.getInsurerName());
}
@Test
void testgetId() {
InsurerDetail Id= new InsurerDetail(1, "Bajaj Insurance", "Gold" ,3000,10);
assertEquals(1,Id.getId());
}
@Test
void testInitiateClaimWhenInsuranceAmountIsGreaterThanPackageAmount() {
InitiateClaim initiateClaim = new InitiateClaim(1," patientName","ailment","treatmentPackageName","insurerName", 5000,3000,0);
assertEquals(0, insuranceClaimServiceImpl.initiateClaim(initiateClaim));
}

}