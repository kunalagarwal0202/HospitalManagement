package com.cts.iptms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.iptms.model.InitiateClaim;

public interface InitiateClaimRepository extends JpaRepository<InitiateClaim, Long>{

}
