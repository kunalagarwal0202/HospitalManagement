package com.cts.iptms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.iptms.model.InsurerDetail;

public interface InsurerDetailRepository extends JpaRepository<InsurerDetail, Long>{

}
