package com.cognizant.iptreatmentofferings;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.iptreatmentofferings.model.IPTreatmentPackage;
import com.cognizant.iptreatmentofferings.model.SpecialistDetail;
import com.cognizant.iptreatmentofferings.repository.IPTreatmentOfferingsPackageDetailRepository;
import com.cognizant.iptreatmentofferings.repository.IPTreatmentOfferingsSpecialistDetailRepository;
import com.cognizant.iptreatmentofferings.service.IPtreatmentofferingsService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class IpTreatmentOfferingsApplicationTests {

 @Mock
IPTreatmentOfferingsPackageDetailRepository iptreatmentofferingsRepository;
@Mock
IPTreatmentOfferingsSpecialistDetailRepository iptreatmentofferingsSpecialistDetaiRepository;
@InjectMocks
IPtreatmentofferingsService iPtreatmentofferingsService;
SpecialistDetail specialistdetail=new SpecialistDetail();
@Test
void testGetIPTreatmentPackages() {
List<IPTreatmentPackage> ipTreatmentPackages = new ArrayList<IPTreatmentPackage>();
when( iptreatmentofferingsRepository.findAll()).thenReturn(ipTreatmentPackages);
assertEquals( ipTreatmentPackages,iPtreatmentofferingsService.getIPTreatmentPackages());
}

@Test
void testGetSpecialists() {
List<SpecialistDetail> specialistDetails = new ArrayList<SpecialistDetail>();
when( iptreatmentofferingsSpecialistDetaiRepository.findAll()).thenReturn(specialistDetails);
assertEquals( specialistDetails,iPtreatmentofferingsService.getSpecialists());
}


@Test
void testSetName() {
specialistdetail.setName("Dr. Kunal Agarwal");
assertEquals("Dr. Kunal Agarwal",specialistdetail.getName());
}
@Test
void testGetName() {
specialistdetail.setName("Dr. Raman Take");
assertEquals("Dr. Raman Take",specialistdetail.getName());
}
}