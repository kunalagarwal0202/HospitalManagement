package com.cts.iptms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import org.mockito.Mock;
import com.cts.iptms.model.PatientDetail;
import com.cts.iptms.model.TreatmentPlan;
import com.cts.iptms.repository.PatientDetailRepository;
import com.cts.iptms.repository.TreatmentPlanRepository;
import com.cts.iptms.service.IPTreatmentServiceImpl;

@SpringBootTest
class DemoApplicationTests {
@Mock
PatientDetailRepository patientdetailRepository;

@Mock
TreatmentPlanRepository tPRepo;
@InjectMocks
IPTreatmentServiceImpl iPTreatmentServiceImpl;
@Test
void testGetTreatmentPlanPackage1() {
PatientDetail patientDetail = new PatientDetail(1,"Shubham",22,"Urology","Package1","12/04/2021");
TreatmentPlan treatmentPlan = iPTreatmentServiceImpl.getTreatmentPlan(patientDetail, 2000) ;
verify(tPRepo,times(1)).save(treatmentPlan);
verify(patientdetailRepository,times(1)).save(patientDetail);
assertEquals("Senior Specialist", treatmentPlan.getSpecialist());

}

}